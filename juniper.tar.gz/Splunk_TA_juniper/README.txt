Splunk Add-on for Juniper version 1.0.1

Copyright (C) 2005-2015 Splunk Inc. All Rights Reserved.

The Splunk Add-on for Juniper allows a Splunk software administrator to pull system logs and traffic statistics from Juniper IDP, Juniper NetScreen Firewall, Juniper NSM, Juniper NSM IDP, Juniper SSLVPN, Junos OS, and Juniper SRX using syslog. This add-on provides CIM-compatible knowledge to use with other Splunk Enterprise apps, such as the Splunk App for Enterprise Security and the Splunk App for PCI Compliance.

Documentation for this add-on is located at: http://docs.splunk.com/Documentation/AddOns/latest/Juniper/About

For installation and set-up instructions, refer to the Installation and Configuration section: http://docs.splunk.com/Documentation/AddOns/latest/Juniper/Hardwareandsoftwarerequirements

For release notes, refer to the Release notes section: http://docs.splunk.com/Documentation/AddOns/latest/Juniper/Releasenotes
